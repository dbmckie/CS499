#include <iostream>
#include "hashTable.h"

using namespace std;

const int NUM_NONTERMS = 8;
const string SYMS_STR[NUM_NONTERMS] = { {"!"}, {"newprompt"}, {"dir"}, {"listprocs"}, {"bye"}, {"="}, {"run"}, {"assignto"} };

enum SYMBOL {COMMENT, NEW_PROMPT, DIR_CHANGE, LIST_PROCS, BYE, GETS, RUN, ASSIGNTO, VARIABLE, VALUE, LAST_TKN, HALT, ERROR};

const SYMBOL CMD_SYNTAX[11][3] = {
	//Comment	
	{COMMENT,       COMMENT,  HALT},
	//Change Prompt
	{NEW_PROMPT, NEW_PROMPT,  HALT},
	//Change Directory
	{DIR_CHANGE, DIR_CHANGE,  LAST_TKN},
	//List processes
	{LIST_PROCS, LIST_PROCS,  HALT},
	//Exit shell
	{BYE,               BYE,  HALT},
	//Gets
	{GETS,             GETS, VALUE},
	//Not built in commands
	{RUN,               RUN,  HALT},
	{ASSIGNTO,      ASSIGNTO, HALT},
	//Assignment
	{VARIABLE,     VARIABLE,  GETS},
	{VALUE,        LAST_TKN,  HALT},
	{LAST_TKN,     LAST_TKN,  HALT}
	

};

const int MAXARGS = 256;

class novsh {
	public:
		novsh();
		bool good();
		void stop();
		string getError();
		string getPrompt();
		void reset();
		bool parse(string &input);
		bool builtInCmd();
		void progCtrlCmd();
		void reap();

	private:
		bool run;
		string error;	
		string prompt;
		int argc;
		string argv[MAXARGS];
		hashTable variables;
		int numProcs;
		int procs[MAXARGS];

		void scan(string &input);
		SYMBOL categorize(int index);
		void setError(SYMBOL state);
		void printTokens();

};
