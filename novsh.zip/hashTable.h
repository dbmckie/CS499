#include "hashNode.h"

const int NUM_HASHTBL_BUCKETS = 100;

class hashTable {
	public:
		hashTable();
		hashTableRef search(string searchKey);
		hashTableRef insert(string newKey, string newValue);
	private:
		hashTableRef bucket[NUM_HASHTBL_BUCKETS];
		int hash(string key);

};
