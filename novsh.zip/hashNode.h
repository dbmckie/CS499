#include <string>

using namespace std;

class hashNode {
	public:
		friend class hashTable;
		hashNode();
		void setKey(string k);
		void setValue(string v);
		string getKey();
		string getValue();

	private:
		string key;
		string value;
		hashNode *next;
};

typedef hashNode * hashTableRef;
