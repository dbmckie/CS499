#include <iostream>
#include "novsh.h"

using namespace std;

int main() {
	novsh shell;
	while (shell.good()) {
		shell.reap();
		cout << shell.getPrompt();
		string input;
		if (!getline(cin, input)) {
			shell.stop();
		} // if getline fails stop shell
		else if (!(shell.parse(input)) && input.length() != 0) {
			cout << shell.getError() << endl;
			shell.reset();
		} // if parser returns bad syntax output error and reset
		else {
			if(!shell.builtInCmd()) {
				shell.progCtrlCmd();
			} // if not built in command run program-control command
			shell.reset();
		} // parser returns good syntax
	} // while input is not eof continue running shell
	return 0;
}
