#include "hashTable.h"
#include <iostream>

// constructor
hashTable::hashTable() {
	for (int i = 0; i < NUM_HASHTBL_BUCKETS; i++) {
		bucket[i] = NULL;
	}
} //hashTable()

// insert a key and value into hashtable.  If key already exists, update value
hashTableRef hashTable::insert(string newKey, string newVal) {
	hashTableRef newNode = search(newKey);
	if (!newNode) {
		int hashValue = hash(newKey);
		newNode = new hashNode;
		newNode->setKey(newKey);
		newNode->next = bucket[hashValue];
		bucket[hashValue] = newNode;
	}
	newNode->setValue(newVal);
	return newNode;
} //insert

// create hash number for key using DJB algorithm
int hashTable::hash(string key) {
	unsigned int hash = 5381;
	for (size_t i = 0; i < key.length(); i++) {
		hash = ((hash << 5) + hash) + key[i];
	}
	hash = hash % NUM_HASHTBL_BUCKETS;
	return hash;
} // hash

// search hashtable for key and return its location or null if not found
hashTableRef hashTable::search(string searchKey) {
	int hashValue = hash(searchKey);
	hashTableRef p = bucket[hashValue];
	while (p) {
		if (p->getKey() == searchKey) {
			return p;
		}
		p = p->next;		
	}
	return NULL;
} // search
