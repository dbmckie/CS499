#include <fstream>
#include <string>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "novsh.h"

// constructor
novsh::novsh() 
	: run{ true }, error{ string() }, prompt{ "novsh > " }, argc{ 0 }, numProcs{ 0 } {
	for (int i = 0; i < MAXARGS; i++) {
		argv[i] = string();
		procs[i] = int();
	} // null initialize all arrays
	variables.insert("ShowTokens", "0");
} // novsh

// reset error and null out argument array before accepting next command 
void novsh::reset() {
	run = true;
	error = string();
	argc = 0;
	for (int i = 0; i < MAXARGS; i++) {
		argv[i] = string();
	} 
} // reset

// get tokens from scanner and parse each token for correct syntax
bool novsh::parse(string &input) {
	scan(input);
	if (run) {
		int index = 0, token = 1, nextState = 2;
		SYMBOL current  = categorize(index);
		int state = (int) current;
		while (state != ERROR && state != HALT) {
			if (current == CMD_SYNTAX[state][token]) {
				current = categorize(++index);
				state = CMD_SYNTAX[state][nextState];
			} // token matches syntax table and parser continues to next token
			else {
				run = false;
				setError((SYMBOL) state);
				state = ERROR;
			} // if next token does not match syntax table the command is invalid
		} // while not in halt state or error state check for correct syntax
	} // if no errors found in scanner parse tokens
	return run;
} // parse

bool novsh::builtInCmd() {
	bool isBuiltIn;
	if (variables.search("ShowTokens")->getValue() == "1") printTokens();
	for (int i = 0; i < argc; i++) {
		if (argv[i][0] == '$') {
			argv[i].erase(0,1);
			hashTableRef location = variables.search(argv[i]);
			if (location == NULL) {
				cout <<  "Variable " + argv[i] + " is not defined." << endl;
				argv[i] = string();
			}
			else {
				argv[i] = location->getValue();
			}
		}
	} // replace variable calls with the stored value in hash table
	if (argv[0] == "run" || argv[0] == "assignto") isBuiltIn = false;
	else if (argv[0] == "!") isBuiltIn = true; // disregard all tokens
	else if (argv[0] == "bye") exit(0); // end shell
	else if (argv[0] == "newprompt") {
		isBuiltIn = true;
		prompt = argv[1];
	} // change prompt
	else if (argv[0] == "listprocs") {
		isBuiltIn = true;
		cout << "Processes" << endl;
		int match = 0;
		int i = 0;
		while (match != numProcs) {
			if (procs[i] != int()) {
				cout << "\t" << procs[i] << endl;
				match++;
			}
		i++;	
		} // loop through list of background processes and display		
	}
	else if (argv[0] == "dir") {
		isBuiltIn = true;
		if (chdir(argv[1].c_str())) {
			cout << argv[1] << ": No such file or directory" << endl; 
		}
	} // change to valid directory
	else {
		isBuiltIn = true;
		variables.insert(argv[0], argv[2]);	
	} // insert defined variable and value into hash table
	return isBuiltIn;
} // builtInCmd

void novsh::progCtrlCmd() {
	int newOut, stdOut;
	int i = 1;
	string var;
	bool backGround = false;
	bool assign = false;
	if (argv[0] == "assignto") {
		assign = true;
		i = 2;
		var = argv[1];
		newOut = open("/tmp/novsh.out", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR| S_IWUSR | S_IRGRP | S_IROTH);
		stdOut = dup(1);
		dup2(newOut, 1);
		close(newOut);	
	} // open file to write STDOUT of child to
	else if (argv[argc - 1] == "<bg>") {
		backGround = true;	
		argv[--argc] = string();
	} // child process will run in background
	int j = 0;
	char *cargv[argc] = { NULL };
	while (i < argc) {
		cargv[j] = (char *) argv[i].c_str();
		i++; j++;
	} // convert string array to char array in order to be passed to execvp
	pid_t pid;	
	if ((pid = fork()) == 0) {
		if (execvp(cargv[0], cargv) < 0)
			cout << cargv[0] << ": Command not found." << endl;
	} // child attemps to execute command
	else {
		if (!backGround) {
			wait(NULL);
		} // <bg> not specified, wait for child to end
		else {
			int k = 0;
			while (procs[k] != int()) k++;
			procs[k] = pid;
			numProcs++;
		} // <bg> specified, add child pid to process array
		if (assign) {
			ifstream infile("/tmp/novsh.out");
			string tmp((istreambuf_iterator<char>(infile)), istreambuf_iterator<char>());
			variables.insert(var, tmp);
			dup2(stdOut, 1);
			close(stdOut);
		} // store output from assignto command into specified variable
	} // parent either waits for child to end or continues
} // progCtrlCmd


void novsh::reap() {
	for (int i = 0; i < MAXARGS; i++) {
		int status;
		if (waitpid(procs[i], &status, WNOHANG) && procs[i] != int()) {
			cout << "Reaping job with pid " << procs[i] << endl;
			kill(procs[i], 0);
			procs[i] = int();
			numProcs--;
		}
	} // search through process array and kill any halted programs
} // reap

SYMBOL novsh::categorize(int index) {
	int i = 0;
	if (argc > 1 && argc - 1 == index) {
		return LAST_TKN;
	}
	else {
		while (argv[index] != SYMS_STR[i] && i < NUM_NONTERMS) i++;
		return (SYMBOL) i;
	}
} // convert scanned tokens to SYMBOL for parser to check correct syntax

void novsh::scan(string &input) {
	bool stringLit = false;
	string token;
	for (size_t i = 0; i < input.length(); i++) {
		char currentChar = input[i];
		if (currentChar == '\"') {
			stringLit = !stringLit;
		} // all quotes must come in pairs
		else if (isspace(currentChar) && !stringLit) {
			argv[argc++] = token;
			token = string();
		} // spaces delimit tokens when not inside quotes
		else {
			token += currentChar;
		} // add current character to token
	}
	if (stringLit) {
		run = false;
		error = "unterminated quoted string";
	} // quotes were not paired correctly and is error
	argv[argc++] = token;
} // scan

void novsh::setError(SYMBOL state) {
	switch(state) {
		case GETS: error = "No value in assignment";
			   break;
		case VALUE: error = "Junk at end of variable assignment";
			    break;
		default: error = "Unrecognized command";
	} // set error based off the state the parser halted in
} // setError

void novsh::printTokens() {
	for (int i = 0; i < argc; i++) {
		cout << "Token = " << argv[i] << endl;
	}
	cout << "--------------" << endl;
} // printTokens

bool novsh::good() { return run; }
void novsh::stop() { run = false; }
string novsh::getPrompt() { return prompt; }
string novsh::getError() { return error; }

