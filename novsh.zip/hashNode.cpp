#include "hashNode.h"

hashNode::hashNode() : key { string() }, value{ string() }, next{ nullptr } { }

void hashNode::setKey(string k) { key = k; }
void hashNode::setValue(string v) { value = v; }
string hashNode::getKey() { return key; }
string hashNode::getValue() { return value; }
